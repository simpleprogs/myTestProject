package mytest.curconverter;

import java.util.List;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root (name="ValCurs")
public class ValCurs {

	@Attribute(name="name")
    public String name;
	
    @Attribute(required=false, name="Date")
    public String Date;
    
    @ElementList(inline=true, name="Valute")
    public List<ValuteProperty> valuts;
}
	

