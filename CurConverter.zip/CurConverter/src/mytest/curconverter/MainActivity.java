package mytest.curconverter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity {
	TextView tvOut;
    Button btnCalc;
    EditText etCash;
    TextView tvConvert;
    TextView tvMarketData;
    
    final String FILENAME = "valutes.xml"; // ��� ����� ��� ���������� ������ �����
    
	int  xmlsize=34;
	String[] propertyMarket = new String[3];
	String[] currency_source_indx = new String[xmlsize];
	String[] currency_final_indx = new String[xmlsize];
	
    String[][] currency_source = new String[xmlsize][5];
	String[][] currency_final = new String[xmlsize][5]; 
   
	String xmlData = "";
	int position_s,position_f;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);
		
		tvOut = (TextView) findViewById(R.id.tvOut);
        btnCalc = (Button) findViewById(R.id.btnCalc);
        etCash = (EditText) findViewById(R.id.etCash);        
        etCash.setBackgroundColor(Color.parseColor("#FFF8DC"));
        tvMarketData = (TextView) findViewById(R.id.tvMarketData);
        
        for(int i = 0; i < 3; i++) propertyMarket[i]="";
        
        for(int i = 0; i < xmlsize; i++){
        	currency_source_indx[i]="";
        	for(int j = 0; j < 5; j++){
        		currency_source[i][j]="";
        		}
        }
        for(int i = 0; i < xmlsize; i++){
        	currency_final_indx[i]="";
        	for(int j = 0; j < 5; j++){
        		currency_final[i][j]="";
        		}
        }    
                
        // �������� xml
        new Thread(new Runnable() {
            @Override
            public void run(){
                if (checkInternet()) {
                    Log.d("my_tag", "���� ����������� - XML inet");
                    
                    try {            
                        xmlData = getURLContent("http://www.cbr.ru/scripts/XML_daily.asp");
                        writeFile(xmlData);
                        Serializer serializer = new Persister();        
                        
                        Reader reader = new StringReader(xmlData);
                        ValCurs vc = serializer.read(ValCurs.class, reader, false);
              
                        propertyMarket[0]=vc.name;
                        propertyMarket[1]=vc.Date;
                        propertyMarket[2]="";
                        for (int i = 0; i < vc.valuts.size(); i++){
                        	currency_source_indx[i]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	for (int j = 0; j < 5; j++){
                        		currency_source[i][0]=vc.valuts.get(i).id;
                        		currency_source[i][1]=vc.valuts.get(i).numCode;
                        		currency_source[i][2]=vc.valuts.get(i).nominal;
                        		currency_source[i][3]=vc.valuts.get(i).value;
                        		currency_source[i][4]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	}
                        	}
                                  
                        for (int i = 0; i < vc.valuts.size(); i++){
                        	currency_final_indx[i]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	for (int j = 0; j < 5; j++){
                        		currency_final[i][0]=vc.valuts.get(i).id;
                        		currency_final[i][1]=vc.valuts.get(i).numCode;
                        		currency_final[i][2]=vc.valuts.get(i).nominal;
                        		currency_final[i][3]=vc.valuts.get(i).value;
                        		currency_final[i][4]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                    		}
                        	}
                        tvMarketData.setText(propertyMarket[0]+"\n"+propertyMarket[1]+propertyMarket[2]);
                    } 
                    catch (Exception e) {
                    	Log.e("SimpleTest", e.getMessage());
                    }
                    
                } else {
                    Log.d("my_tag", "��� ����������� - XML from file");
                    
                    try {            
                        
                        readFile();
                        Serializer serializer = new Persister();        
                        
                        Reader reader = new StringReader(xmlData);
                        ValCurs vc = serializer.read(ValCurs.class, reader, false);
                        propertyMarket[0]=vc.name;
                        propertyMarket[1]=vc.Date;
                        propertyMarket[2]="���";                      
                        for (int i = 0; i < vc.valuts.size(); i++){
                        	currency_source_indx[i]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	for (int j = 0; j < 5; j++){
                        		currency_source[i][0]=vc.valuts.get(i).id;
                        		currency_source[i][1]=vc.valuts.get(i).numCode;
                        		currency_source[i][2]=vc.valuts.get(i).nominal;
                        		currency_source[i][3]=vc.valuts.get(i).value;
                        		currency_source[i][4]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	}
                        	}
                                  
                        for (int i = 0; i < vc.valuts.size(); i++){
                        	currency_final_indx[i]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                        	for (int j = 0; j < 5; j++){
                        		currency_final[i][0]=vc.valuts.get(i).id;
                        		currency_final[i][1]=vc.valuts.get(i).numCode;
                        		currency_final[i][2]=vc.valuts.get(i).nominal;
                        		currency_final[i][3]=vc.valuts.get(i).value;
                        		currency_final[i][4]=vc.valuts.get(i).charCode+" - "+vc.valuts.get(i).name;
                    		}
                        	}
                        tvMarketData.setText(propertyMarket[0]+"\n"+propertyMarket[1]+"("+propertyMarket[2]+")");
                    } 
                    catch (Exception e) {
                    	Log.e("SimpleTest", e.getMessage());
                    }
                    
                    
                }
            }
        }).start();                         
        // �������� xml
        
        
		// ������� ��� spinner currency_source
        ArrayAdapter<String> adapter_s = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, currency_source_indx);
        adapter_s.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //----------
        ArrayAdapter<String> adapter_f = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, currency_final_indx);
        adapter_f.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //----------
        Spinner spinner_s = (Spinner) findViewById(R.id.spinner_s);
        spinner_s.setAdapter(adapter_s);
        spinner_s.setPrompt("����� �c������ ������"); // ��������� 
              			  // �������� �������
        
        Spinner spinner_f = (Spinner) findViewById(R.id.spinner_f);
        spinner_f.setAdapter(adapter_f);
        spinner_f.setPrompt("����� �������� ������"); // ���������
            			  // �������� �������
        
             
        // ������������� ���������� ������� ��� �������� ������
        spinner_s.setOnItemSelectedListener(new OnItemSelectedListener() {
      @Override
      public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    	  position_s=position;
      }
      @Override
      public void onNothingSelected(AdapterView<?> arg0) {
      }
    });
     //------------------------
     // ������������� ���������� ������� ��� �������� ������
        spinner_f.setOnItemSelectedListener(new OnItemSelectedListener() {
      @Override
      public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        position_f=position;  
      }
      @Override
      public void onNothingSelected(AdapterView<?> arg0) {
      }
    });
        
        
     // ������������� ���������� ��� ������ ������
        etCash.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

            	if (etCash.getText().length()!=0){
            		etCash.setBackgroundColor(Color.parseColor("#FFF8DC"));
            		}else{
            		//Toast.makeText(getBaseContext(), "������������ ��������� �����!", Toast.LENGTH_SHORT).show();
            		etCash.setBackgroundColor(Color.parseColor("#FFF8DC"));
            		}         

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {}
         });   
        
     // ������������� ���������� ������� ��� ������
        OnClickListener oclBtnOk = new OnClickListener() {
            @Override
            public void onClick(View v) {
                
            	String value_source = currency_source[position_s][3].replace(',', '.');
            	String nominal_source = currency_source[position_s][2].replace(',','.');
            	float a=Float.parseFloat(value_source)/Float.parseFloat(nominal_source);
            	
            	String value_final = currency_final[position_f][3].replace(',', '.');
            	String nominal_final = currency_final[position_f][2].replace(',','.');
            	float b=Float.parseFloat(value_final)/Float.parseFloat(nominal_final);
            	
            	if (etCash.getText().length()!=0){
            		etCash.setBackgroundColor(Color.parseColor("#FFF8DC"));
            		float result=(Float.valueOf(etCash.getText().toString())*a)/b;
            		DecimalFormat decimalFormat = new DecimalFormat("##0.####");
                	String format = decimalFormat.format(result);
                	tvOut.setText(format);
            		}else{
            		//Toast.makeText(getBaseContext(), "������������ ��������� �����!", Toast.LENGTH_SHORT).show();
            		etCash.setBackgroundColor(Color.parseColor("#FFF8DC"));
            		}
            	
            }
        };
        
        btnCalc.setOnClickListener(oclBtnOk);
       	
	}

	
	//���������� ������ ����� ����� � ����
	void writeFile(String strData) {
	    try {
	      // �������� ����� ��� ������
	      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
	          openFileOutput(FILENAME, MODE_PRIVATE)));
	      // ����� ������
	      bw.write(strData);
	      Log.d("my_tag", "XML �������");
	      // ��������� �����
	      bw.close();
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	  }	
	//������ ������ ����� ����� �� �����
	void readFile() {
        FileInputStream stream = null;
        StringBuilder sb = new StringBuilder();
        String line;
 
        try {
            stream = openFileInput(FILENAME);
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            } finally {
                stream.close();
            }
 
            xmlData=sb.toString();

        } catch (Exception e) {
            Log.d("my_tag", "����� ��� ��� ��������� ������ ��� ������");
        }
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
		
	// �������� ����������� � ��������
    public boolean checkInternet() {
 
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
 
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        // �������� �����������
        if (activeNetwork != null && activeNetwork.isConnected()) {
            try {
                // ���� ����������� �������� �������
                URL url = new URL("http://www.google.com/");
                HttpURLConnection urlc = (HttpURLConnection)url.openConnection();
                urlc.setRequestProperty("User-Agent", "test");
                urlc.setRequestProperty("Connection", "close");
                urlc.setConnectTimeout(1000); // Timeout � ��������
                urlc.connect();
                // ������ ������� OK
                if (urlc.getResponseCode() == 200) {
                    return true;
                }
                // ����� �������� �����������
                return false;
 
            } catch (IOException e) {
                Log.d("my_tag", "������ �������� ����������� � ���������", e);
                return false;
            }
        }
 
        return false;
    }
	
    //����������� ������� �� ���������� url
    public String getURLContent(String p_sURL)
    {
        URL oURL;
        URLConnection oConnection;
        BufferedReader oReader;
        String sLine;
        StringBuilder sbResponse;
        String sResponse = null;

        try
        {
            oURL = new URL(p_sURL);
            oConnection = oURL.openConnection();
            oConnection.connect();
            oReader = new BufferedReader(new InputStreamReader(oConnection.getInputStream(),"Cp-1251"));
            sbResponse = new StringBuilder();

            while((sLine = oReader.readLine()) != null)
            {
                sbResponse.append(sLine);
            }

            sResponse = sbResponse.toString();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return sResponse;
    }
    

    
}
